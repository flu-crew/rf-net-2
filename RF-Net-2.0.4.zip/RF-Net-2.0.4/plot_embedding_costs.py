#!/usr/bin/env python3

import matplotlib.pyplot as plt
import re
import sys

def plot_costs(net_path: str):
    net_file = open(net_path, 'r')
    reticulations = []
    distances = []
    for network in net_file:
        match = re.search('\[&r=([0-9]+),dist=([0-9.]+)\];',network.strip())
        if(match!=None):
            reticulations.append(int(match.group(1)))
            distances.append(float(match.group(2)))
    plt.plot(reticulations,distances,'-o',label=net_file.name.split(".")[0])
    plt.title("Embedding cost dynamic")
    plt.xlabel("Number of reticulations")
    plt.ylabel("Embedding cost")
    plt.show()
    
if __name__ == '__main__':
    args = sys.argv[1:]
    plot_costs(args[0])

